let t={active:!1,prompt:"",role:"DEFAULT",rounds:1,currentRound:0,geminiTabId:null,chatGPTTabId:null,statusLog:[]};function c(n,r){return new Promise((a,o)=>{chrome.tabs.sendMessage(n,r,e=>{const s=chrome.runtime.lastError;s?o(s):a(e)})})}function l(n){return chrome.scripting.executeScript({target:{tabId:n},files:["content.js"]})}async function m(n){try{await l(n)}catch(r){console.warn("Injection warning:",(r==null?void 0:r.message)||r)}}chrome.runtime.onMessage.addListener((n,r,a)=>{if(n.action==="startBrainstorm")return chrome.tabs.query({},o=>{const e=o.find(i=>i.url&&i.url.includes("gemini.google.com")),s=o.find(i=>i.url&&(i.url.includes("chatgpt.com")||i.url.includes("openai.com")));if(!e||!s||!e.id||!s.id){a({success:!1,error:`Missing tabs. Found Gemini: ${!!e}, ChatGPT: ${!!s}. Open both sites.`});return}t.active=!0,t.prompt=n.topic||n.prompt,t.rounds=n.rounds||3,t.role="IDEATOR",t.currentRound=0,t.statusLog=[],t.geminiTabId=e.id,t.chatGPTTabId=s.id,d(),a({success:!0})}),!0;if(n.action==="stopBrainstorm")return t.active=!1,a({success:!0}),!0;if(n.action==="getBrainstormState")return a(t),!1});async function d(){for(;t.active&&t.currentRound<t.rounds;){if(t.currentRound++,console.log(`[Brainstorm] Round ${t.currentRound}/${t.rounds}`),t.geminiTabId===null||t.chatGPTTabId===null){console.error("Tabs lost during loop."),t.active=!1;break}const n=await u(t.geminiTabId,t.prompt),r=p(t.role,t.prompt,n),o=`Refine and improve this based on ChatGPT feedback:

${await u(t.chatGPTTabId,r)}`;await u(t.geminiTabId,o),await new Promise(e=>setTimeout(e,2e3))}t.active=!1,console.log("[Brainstorm] Completed.")}async function u(n,r){await m(n);try{await c(n,{action:"getLastResponse"})}catch(e){console.warn("getLastResponse failed:",(e==null?void 0:e.message)||e)}let a=0,o=0;try{const e=await c(n,{action:"getUserTurnCount"});o=(e==null?void 0:e.count)??0}catch(e){console.warn("getUserTurnCount failed:",(e==null?void 0:e.message)||e)}for(;a<3;){a++;try{await c(n,{action:"runPrompt",text:r})}catch(e){console.warn("runPrompt failed:",(e==null?void 0:e.message)||e)}await new Promise(e=>setTimeout(e,2500));try{const e=await c(n,{action:"getUserTurnCount"});if(((e==null?void 0:e.count)??o)>o)break;console.warn(`Prompt did not post, retrying (${a})...`)}catch{break}}try{await c(n,{action:"waitForDone"})}catch(e){console.warn("waitForDone failed:",(e==null?void 0:e.message)||e)}try{const e=await c(n,{action:"getLastResponse"});return(e==null?void 0:e.text)||""}catch(e){return console.warn("getLastResponse (final) failed:",(e==null?void 0:e.message)||e),""}}function p(n,r,a){switch(n){case"REFINER":return`You are a **Refiner**.

Original prompt:
${r}

Gemini response:
${a}

Task: Improve clarity, structure, and actionability. Output only the improved answer.`;case"CRITIC":return`You are a **Critic**.

Original prompt:
${r}

Gemini response:
${a}

Task: Identify weaknesses, missing info, and risks. Suggest improvements.`;case"SYNTHESIZER":return`You are a **Synthesizer**.

Original prompt:
${r}

Gemini response:
${a}

Task: Combine into a cohesive best-of answer with clear sections.`;default:return`Original prompt:
${r}

Gemini response:
${a}

Now answer as ChatGPT with your best response.`}}
