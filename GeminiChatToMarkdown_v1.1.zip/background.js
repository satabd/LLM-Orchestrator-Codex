// Brainstorm Orchestrator (Role-Based)
// Runs in MV3 Service Worker context.

let brainstormState = {
    active: false,
    prompt: "",
    role: "DEFAULT",
    rounds: 1,
    currentRound: 0,
    geminiTabId: null,
    chatGPTTabId: null
};

// ---- Promise wrappers (more reliable than relying on implicit promise support) ----
function sendMessage(tabId, message) {
    return new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tabId, message, (resp) => {
            const err = chrome.runtime.lastError;
            if (err) reject(err);
            else resolve(resp);
        });
    });
}

function executeScript(tabId) {
    return chrome.scripting.executeScript({
        target: { tabId },
        files: ["content.fixed.js"] // <-- use fixed content script
    });
}

async function ensureInjected(tabId) {
    try {
        await executeScript(tabId);
    } catch (err) {
        // Injection can fail on restricted pages or if the tab is not ready.
        console.warn("Injection warning:", err?.message || err);
    }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "startBrainstorm") {
        brainstormState.active = true;
        brainstormState.prompt = request.prompt;
        brainstormState.role = request.role;
        brainstormState.rounds = request.rounds;
        brainstormState.currentRound = 0;

        // Expect the UI to pass tab IDs
        brainstormState.geminiTabId = request.geminiTabId;
        brainstormState.chatGPTTabId = request.chatGPTTabId;

        runBrainstormLoop();
        sendResponse({ status: "started" });
        return true;
    }

    if (request.action === "stopBrainstorm") {
        brainstormState.active = false;
        sendResponse({ status: "stopped" });
        return true;
    }
});

// Master loop
async function runBrainstormLoop() {
    while (brainstormState.active && brainstormState.currentRound < brainstormState.rounds) {
        brainstormState.currentRound++;

        console.log(`[Brainstorm] Round ${brainstormState.currentRound}/${brainstormState.rounds}`);

        // 1) Send to Gemini
        const geminiOutput = await sendPromptToTab(brainstormState.geminiTabId, brainstormState.prompt);

        // 2) Send Gemini output to ChatGPT
        const chatGPTPrompt = buildRolePrompt(brainstormState.role, brainstormState.prompt, geminiOutput);
        const chatGPTOutput = await sendPromptToTab(brainstormState.chatGPTTabId, chatGPTPrompt);

        // 3) Send ChatGPT output back to Gemini (optional refinement loop)
        const geminiRefinePrompt = `Refine and improve this based on ChatGPT feedback:\n\n${chatGPTOutput}`;
        await sendPromptToTab(brainstormState.geminiTabId, geminiRefinePrompt);

        // Small delay between rounds
        await new Promise(r => setTimeout(r, 2000));
    }

    brainstormState.active = false;
    console.log("[Brainstorm] Completed.");
}

// Send prompt + wait for completion + fetch response
async function sendPromptToTab(tabId, prompt) {
    await ensureInjected(tabId);

    // Grab previous response (optional, for debug)
    try {
        await sendMessage(tabId, { action: "getLastResponse" });
    } catch (err) {
        console.warn("getLastResponse failed:", err?.message || err);
    }

    // Try sending prompt up to 3 times if the user-message count doesn't increase
    let tries = 0;
    let userTurnsBefore = 0;

    try {
        const countResp = await sendMessage(tabId, { action: "getUserTurnCount" });
        userTurnsBefore = countResp?.count ?? 0;
    } catch (err) {
        console.warn("getUserTurnCount failed:", err?.message || err);
    }

    while (tries < 3) {
        tries++;

        try {
            await sendMessage(tabId, { action: "runPrompt", text: prompt });
        } catch (err) {
            console.warn("runPrompt failed:", err?.message || err);
        }

        await new Promise(r => setTimeout(r, 2500));

        try {
            const afterResp = await sendMessage(tabId, { action: "getUserTurnCount" });
            const after = afterResp?.count ?? userTurnsBefore;
            if (after > userTurnsBefore) break;
            console.warn(`Prompt did not post, retrying (${tries})...`);
        } catch (err) {
            // If we can't read the count, don't loop forever
            break;
        }
    }

    // Wait for assistant to finish generating
    try {
        await sendMessage(tabId, { action: "waitForDone" });
    } catch (err) {
        console.warn("waitForDone failed:", err?.message || err);
    }

    // Get final response
    try {
        const finalResp = await sendMessage(tabId, { action: "getLastResponse" });
        return finalResp?.text || "";
    } catch (err) {
        console.warn("getLastResponse (final) failed:", err?.message || err);
        return "";
    }
}

// Role Prompt Templates
function buildRolePrompt(role, originalPrompt, geminiOutput) {
    switch (role) {
        case "REFINER":
            return `You are a **Refiner**.\n\nOriginal prompt:\n${originalPrompt}\n\nGemini response:\n${geminiOutput}\n\nTask: Improve clarity, structure, and actionability. Output only the improved answer.`;

        case "CRITIC":
            return `You are a **Critic**.\n\nOriginal prompt:\n${originalPrompt}\n\nGemini response:\n${geminiOutput}\n\nTask: Identify weaknesses, missing info, and risks. Suggest improvements.`;

        case "SYNTHESIZER":
            return `You are a **Synthesizer**.\n\nOriginal prompt:\n${originalPrompt}\n\nGemini response:\n${geminiOutput}\n\nTask: Combine into a cohesive best-of answer with clear sections.`;

        default:
            return `Original prompt:\n${originalPrompt}\n\nGemini response:\n${geminiOutput}\n\nNow answer as ChatGPT with your best response.`;
    }
}