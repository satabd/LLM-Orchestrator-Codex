document.addEventListener('DOMContentLoaded', () => {
  const saveBtn = document.getElementById('saveBtn');
  const copyBtn = document.getElementById('copyBtn');
  const autoCopyToggle = document.getElementById('autoCopyToggle');

  function getActiveTab() {
    return new Promise(resolve => chrome.tabs.query({ active: true, currentWindow: true }, tabs => resolve(tabs?.[0] || null)));
  }

  function execContentScript(tabId) {
    // Inject content script (safe to call multiple times)
    return chrome.scripting.executeScript({
      target: { tabId },
      files: ['content.fixed.js'] // <-- use the fixed content script
    });
  }

  function sendToTab(tabId, msg) {
    return new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(tabId, msg, (resp) => {
        const err = chrome.runtime.lastError;
        if (err) reject(err);
        else resolve(resp);
      });
    });
  }

  function inferPrefixFromUrl(url) {
    try {
      const host = new URL(url).hostname;
      if (host.includes('gemini.google.com')) return 'gemini-chat';
      if (host.includes('chatgpt.com') || host.includes('openai.com')) return 'chatgpt-chat';
    } catch (e) { }
    return 'ai-chat';
  }

  async function handleAction(action) {
    const tab = await getActiveTab();
    if (!tab?.id) return;

    try {
      // Ensure our content script is present
      await execContentScript(tab.id);

      // Ask the already-injected content script to scrape the whole conversation
      const response = await sendToTab(tab.id, { action: 'scrapeConversation' });
      const markdownText = response?.text || '';

      if (!markdownText.trim()) {
        alert("No content found.");
        return;
      }

      if (action === 'save') {
        downloadMarkdown(markdownText, tab.url);
      } else if (action === 'copy') {
        await navigator.clipboard.writeText(markdownText);
        alert("Copied to clipboard!");
      }

    } catch (err) {
      console.error("Export failed:", err);
      alert("Export failed. Make sure you're on ChatGPT or Gemini and refresh the page once.");
    }
  }

  function downloadMarkdown(markdownText, url) {
    const blob = new Blob([markdownText], { type: 'text/markdown' });
    const urlObj = URL.createObjectURL(blob);
    const a = document.createElement('a');

    const prefix = inferPrefixFromUrl(url);
    const now = new Date();
    const safeTs = now.toISOString().replace(/[:.]/g, '-');

    a.href = urlObj;
    a.download = `${prefix}-${safeTs}.md`;
    a.click();

    URL.revokeObjectURL(urlObj);
  }

  saveBtn.addEventListener('click', () => handleAction('save'));
  copyBtn.addEventListener('click', () => handleAction('copy'));

  // Load and apply stored auto-copy setting
  chrome.storage.local.get(['autoCopyEnabled'], (result) => {
    autoCopyToggle.checked = !!result.autoCopyEnabled;
  });

  autoCopyToggle.addEventListener('change', async () => {
    const enabled = autoCopyToggle.checked;
    chrome.storage.local.set({ autoCopyEnabled: enabled });

    const tab = await getActiveTab();
    if (!tab?.id) return;

    try {
      await execContentScript(tab.id);
      await sendToTab(tab.id, { action: 'toggleAutoCopy', enabled });
    } catch (err) {
      console.error('Failed to toggle auto-copy:', err);
    }
  });
});