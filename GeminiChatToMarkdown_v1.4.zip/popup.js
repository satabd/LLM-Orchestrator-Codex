document.addEventListener('DOMContentLoaded', () => {
  // --- UI Elements ---
  const saveBtn = document.getElementById('saveBtn');
  const copyBtn = document.getElementById('copyBtn');
  const autoCopyToggle = document.getElementById('autoCopyToggle');
  const topicInput = document.getElementById('topicInput');
  const roundsInput = document.getElementById('roundsInput');
  const startBrainstormBtn = document.getElementById('startBrainstormBtn');
  const stopBrainstormBtn = document.getElementById('stopBrainstormBtn');
  const statusDiv = document.getElementById('status');

  // --- Helper Functions ---

  function getActiveTab() {
    return new Promise(resolve => chrome.tabs.query({ active: true, currentWindow: true }, tabs => resolve(tabs?.[0] || null)));
  }

  function execContentScript(tabId) {
    return chrome.scripting.executeScript({
      target: { tabId },
      files: ['content.js']
    });
  }

  function sendToTab(tabId, msg) {
    return new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(tabId, msg, (resp) => {
        const err = chrome.runtime.lastError;
        if (err) reject(err);
        else resolve(resp);
      });
    });
  }

  function inferPrefixFromUrl(url) {
    try {
      const host = new URL(url).hostname;
      if (host.includes('gemini.google.com')) return 'gemini-chat';
      if (host.includes('chatgpt.com') || host.includes('openai.com')) return 'chatgpt-chat';
    } catch (e) { }
    return 'ai-chat';
  }

  function updateStatus(lines) {
    if (!statusDiv) return;
    statusDiv.textContent = lines.join('\n');
    statusDiv.scrollTop = statusDiv.scrollHeight;
  }

  async function pollBrainstormStatus() {
    chrome.runtime.sendMessage({ action: 'getBrainstormState' }, (state) => {
      if (chrome.runtime.lastError || !state) return;

      if (state.active) {
        startBrainstormBtn.style.display = 'none';
        stopBrainstormBtn.style.display = 'inline-block';
        topicInput.disabled = true;
        roundsInput.disabled = true;
      } else {
        startBrainstormBtn.style.display = 'inline-block';
        stopBrainstormBtn.style.display = 'none';
        topicInput.disabled = false;
        roundsInput.disabled = false;
      }

      updateStatus(state.statusLog || []);
    });
  }

  // --- Export / Copy Logic ---

  async function handleAction(action) {
    const tab = await getActiveTab();
    if (!tab?.id) return;

    try {
      await execContentScript(tab.id);
      const response = await sendToTab(tab.id, { action: 'scrapeConversation' });
      const markdownText = response?.text || '';

      if (!markdownText.trim()) {
        alert("No content found.");
        return;
      }

      if (action === 'save') {
        downloadMarkdown(markdownText, tab.url);
      } else if (action === 'copy') {
        await navigator.clipboard.writeText(markdownText);
        alert("Copied to clipboard!");
      }

    } catch (err) {
      console.error("Export failed:", err);
      alert("Export failed. Make sure you're on ChatGPT or Gemini and refresh the page once.");
    }
  }

  function downloadMarkdown(markdownText, url) {
    const blob = new Blob([markdownText], { type: 'text/markdown' });
    const urlObj = URL.createObjectURL(blob);
    const a = document.createElement('a');

    const prefix = inferPrefixFromUrl(url);
    const now = new Date();
    const safeTs = now.toISOString().replace(/[:.]/g, '-');

    a.href = urlObj;
    a.download = `${prefix}-${safeTs}.md`;
    a.click();

    URL.revokeObjectURL(urlObj);
  }

  saveBtn.addEventListener('click', () => handleAction('save'));
  copyBtn.addEventListener('click', () => handleAction('copy'));

  // --- Auto-Copy Logic ---

  chrome.storage.local.get(['autoCopyEnabled'], (result) => {
    if (autoCopyToggle) autoCopyToggle.checked = !!result.autoCopyEnabled;
  });

  if (autoCopyToggle) {
    autoCopyToggle.addEventListener('change', async () => {
      const enabled = autoCopyToggle.checked;
      chrome.storage.local.set({ autoCopyEnabled: enabled });

      const tab = await getActiveTab();
      if (!tab?.id) return;

      try {
        await execContentScript(tab.id);
        await sendToTab(tab.id, { action: 'toggleAutoCopy', enabled });
      } catch (err) { }
    });
  }

  // --- Brainstorm Loop Logic ---

  startBrainstormBtn.addEventListener('click', () => {
    const topic = topicInput.value.trim();
    const rounds = parseInt(roundsInput.value, 10) || 3;

    if (!topic) {
      alert("Please enter a topic.");
      return;
    }

    chrome.runtime.sendMessage({ action: 'startBrainstorm', topic, rounds }, (resp) => {
      if (resp && resp.success) {
        pollBrainstormStatus();
      } else {
        alert("Failed to start: " + (resp?.error || "Unknown error"));
      }
    });
  });

  stopBrainstormBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'stopBrainstorm' });
  });

  // Start polling for status immediately
  setInterval(pollBrainstormStatus, 1000);
  pollBrainstormStatus();
});